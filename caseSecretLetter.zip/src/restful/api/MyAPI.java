package restful.api;

import java.util.Random;
import javax.ws.rs.FormParam;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;

//1.张华解密
//2770d0b53955accfd6b97b160c699ebe7e0aeb843f1fff9cfd9498e8c6ae50358ffd37174f3880efcab8523ef692fcdd
//http://localhost:8080/caseSecretLetter/jsp/decodeKey.jsp

//2.张华创建秘钥
//0160478
//http://localhost:8080/caseSecretLetter/jsp/createCipherKey.jsp 

////3.张华第二次创建秘钥
//http://localhost:8080/caseSecretLetter/jsp/cipher.jsp

//4.李俊解码张华密钥
//http://localhost:8080/caseSecretLetter/jsp/decodeText.jsp

@Path("/letter/")
public class MyAPI {
	/**
	 * 李俊解密
	 * 
	 * @param key  密钥
	 * @param word 密文
	 * @return
	 */
	@POST
	@Produces("text/html;charset=utf-8")
	@Path("/decodeCipherText")
	public String decodeCipherText(@FormParam("key") String key, @FormParam("word") String word) {
		return parseCipherC(key, word);
	}

	/**
	 * 张华二次加密
	 * 
	 * @param key  密钥
	 * @param word 要加密的明文
	 * @return 密文
	 */
	@POST
	@Produces("text/html;charset=utf-8")
	@Path("/createCipherText")
	public String createCipherText(@FormParam("key") String key, @FormParam("word") String word) {
		// 短的放前面
		return parseCipherB(word, key);
	}

	/**
	 * 张华用自己学号创建密文
	 * 
	 * @param id  学号
	 * @param key 解密后的明文
	 * @return
	 */
	@POST
	@Produces("text/html;charset=utf-8")
	@Path("/createCipherKey")
	public String createCipherKey(@FormParam("id") String id, @FormParam("key") String key) {
		// 短的放后面
		return parseCipherB(key, id);

	}

	/**
	 * 张华解密
	 * 
	 * @param cipher 密文
	 * @return
	 */
	@POST
	@Produces("text/html;charset=utf-8")
	@Path("/getCipherKey")
	public String getCipherKey(@FormParam("cipher") String cipher) {
		return parseCipherA(cipher);
	}

	/**
	 * 算法C,为算法A的逆运算
	 * 
	 * @param secretKey 密钥
	 * @param text      密文
	 * @return 明文
	 */
	public static String parseCipherC(String secretKey, String text) {
		StringBuilder plainText = new StringBuilder();// 真实明文
		int plainTextLength = text.length() / 2;// 明文真实长度
		String useSecretKey = secretKey.substring(0, plainTextLength);// 与明文进行异或运算的密钥
		int j = 0;
		for (int i = 0; i < text.length(); i = i + 4) {
			// 截取四个
			String s = text.substring(i, i + 4);
			String c = s.substring(0, 2);
			String r = s.substring(2, 4);// 随机数不应该去掉
			char k = useSecretKey.charAt(j++);// 注意索引,不得一样
			// 将16进制解析成10进制整数
			Integer CiB = Integer.parseInt(c, 16);
			Integer RiB = Integer.parseInt(r, 16);
			plainText.append((char) (CiB ^ RiB ^ k));
		}
		return plainText.toString();
	}

	/**
	 * 算法B
	 *
	 * @param text      明文
	 * @param secretKey 密钥
	 * @return
	 */
	public static String parseCipherB(String text, String secretKey) {
		StringBuilder newKey = new StringBuilder();
		Random random = new Random();
		for (int i = 0; i < text.length(); i++) {
			// TODO 这里传入的是16进制,是否要考虑把16进制转成10进制再进行与运算
			// 这里没有转,而是通过ASCII表
			char Ti = text.charAt(i);
			char Ki = secretKey.charAt(i % secretKey.length());
			Integer V = Ti ^ Ki;
			Integer R = random.nextInt(256);// 随机数
			Integer C = V ^ R;
			newKey.append(String.format("%02X", C));
			newKey.append(String.format("%02X", R));
		}
		// 小写(大小写无所谓)
		return newKey.toString().toLowerCase();
	}

	/**
	 * 算法A,进行解密
	 *
	 * @param cipher 加密后的数据
	 * @return 解密后的明文
	 */
	public static String parseCipherA(String cipher) {
		// 明文
		StringBuilder text = new StringBuilder();
		// 解析
		try {
			for (int i = 0; i < cipher.length(); i = i + 4) {
				// 截取四个
				String s = cipher.substring(i, i + 4);
				// 截取前后两个字符
				String Ci = s.substring(0, 2);
				String Ri = s.substring(2, 4);
				// 将16进制解析成10进制整数
				Integer CiB = Integer.parseInt(Ci, 16);
				Integer RiB = Integer.parseInt(Ri, 16);
				// 进行异或运算,并且构造字符串
				text.append((char) (CiB ^ RiB));
			}
			return text.toString();
		} catch (Exception e) {
			e.printStackTrace();
			return "密文格式不正确，请重新输入!";
		}
	}

}
