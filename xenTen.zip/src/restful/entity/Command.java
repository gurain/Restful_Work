package restful.entity;

public class Command {

    private String zoneCode;
    private Double targetPosX;
    private Double targetPosY;
    private Double targetPosZ;
    private Integer power;
    private Integer duration;


    public Command()
    {
        
    }
    
    public Command(String zoneCode, Double targetPosX, Double targetPosY, Double targetPosZ, Integer power, Integer duration) {
        this.zoneCode = zoneCode;
        this.targetPosX = targetPosX;
        this.targetPosY = targetPosY;
        this.targetPosZ = targetPosZ;
        this.power = power;
        this.duration = duration;
    }

    public String getZoneCode() {
        return zoneCode;
    }

    public void setZoneCode(String zoneCode) {
        this.zoneCode = zoneCode;
    }

    public Double getTargetPosX() {
        return targetPosX;
    }

    public void setTargetPosX(Double targetPosX) {
        this.targetPosX = targetPosX;
    }

    public Double getTargetPosY() {
        return targetPosY;
    }

    public void setTargetPosY(Double targetPosY) {
        this.targetPosY = targetPosY;
    }

    public Double getTargetPosZ() {
        return targetPosZ;
    }

    public void setTargetPosZ(Double targetPosZ) {
        this.targetPosZ = targetPosZ;
    }

    public Integer getPower() {
        return power;
    }

    public void setPower(Integer power) {
        this.power = power;
    }

    public Integer getDuration() {
        return duration;
    }

    public void setDuration(Integer duration) {
        this.duration = duration;
    }
	

}
