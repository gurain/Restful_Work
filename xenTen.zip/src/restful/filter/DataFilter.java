package restful.filter;

import java.io.IOException;

import java.net.URI;

import javax.servlet.http.HttpServletRequest;
import javax.ws.rs.container.ContainerRequestContext;
import javax.ws.rs.container.ContainerRequestFilter;
import javax.ws.rs.container.ContainerResponseContext;
import javax.ws.rs.container.ContainerResponseFilter;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.Response.Status;

import net.sf.json.JSONArray;
import net.sf.json.JSONObject;
import restful.bean.ModifiedResult;
import restful.bean.Result;

public class DataFilter<E> implements ContainerRequestFilter, ContainerResponseFilter {
	private @Context HttpServletRequest request;
	private URI invalidatedURI = URI.create("/invalidated");

	// 响应过滤器
	@Override
	public void filter(ContainerRequestContext containerRequestContext,
			ContainerResponseContext containerResponseContext) throws IOException {
		// 获取状态码
		int statusCode = containerResponseContext.getStatus();
		if (statusCode >= 400 && statusCode < 600) {
			// 跳过响应过滤器的执行
			return;
		}

		// session中存放的数据
		JSONArray oldCommandsObject = (JSONArray) request.getSession().getAttribute("commands");
		JSONArray newCommandsObject = (JSONArray) request.getSession().getAttribute("refreshData");

		// 获取请求路径
		String url = containerRequestContext.getUriInfo().getPath();
		Object entity = containerResponseContext.getEntity();

		// 进行判断
		if ("/data/readCommand".equals(url)) {
			// Result类型
			Result result = (Result) entity;
			result.setCode("0");
			result.setDescription("指令接收成功!");
			result.setNextAction("");
			// 设置响应体
			containerResponseContext.setEntity(result);
		} else if ("/data/refresh".equals(url)) { // && authoration(containerRequestContext)

//			// 便利旧的jsonArray对象
//			for (int i = 0; i < oldCommandsObject.size(); i++) {
//				// 获取新的jsonObject对象,并且转换成Command对象
//				Command command = (Command) JSONObject.toBean(newCommandsObject.getJSONObject(i), Command.class);
//				// 设置旧的jsonArray对象
//				oldCommandsObject.set(i, command);
//			}

			// 遍历 oldCommandsObject
			for (int i = 0; i < oldCommandsObject.size(); i++) {
	            // 获取 oldCommandsObject 中的 JSONObject
	            JSONObject oldCommand = oldCommandsObject.getJSONObject(i);
	            // 根据索引获取 newCommandsObject 中的 JSONObject
	            JSONObject newCommand = newCommandsObject.getJSONObject(i);
	            // 将 oldCommand 中的属性替换为 newCommand 中的属性
	            for (Object key : oldCommand.keySet()) {
	                oldCommand.put(key, newCommand.get(key));
	            }
			}

			// Result类型
			Result re = new Result();
			re.setCode("0");
			re.setDescription("指令接收成功!");
			re.setNextAction("");

			// ModifiedResult类型
			ModifiedResult result = (ModifiedResult) entity;
			result.setOpReturn(re);
			result.setDataReturn(oldCommandsObject);

			// 设置响应体
			containerResponseContext.setEntity(result);
		}

	}

	// 请求过滤器
	@Override
	public void filter(ContainerRequestContext containerRequestContext) throws IOException {
		String url = containerRequestContext.getUriInfo().getPath();
		System.out.println(url);
		// 授权失败,返回404页面
		if (!authoration(containerRequestContext)) {
			containerRequestContext.abortWith(Response.status(Status.NOT_FOUND).location(invalidatedURI).build());
		}
	}

	// 是否授权
	private boolean authoration(ContainerRequestContext containerRequestContext) {
		String url = containerRequestContext.getUriInfo().getPath();
		if ("/data/refresh".equals(url)) {
			Integer s = Integer.parseInt(request.getParameter("s"));
			Integer x = Integer.parseInt(request.getParameter("x"));
			Integer r = Integer.parseInt(request.getParameter("r"));
			if (s % x == r) {
				return true;
			} else {
				return false;
			}
		}
		// 默认同意授权
		return true;
	}

}
