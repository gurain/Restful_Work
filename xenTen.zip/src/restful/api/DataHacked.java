package restful.api;

import net.sf.json.JSONArray;
import javax.servlet.http.HttpServletRequest;
import javax.ws.rs.FormParam;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.Context;
import restful.bean.Result;
import restful.bean.ModifiedResult;

@Path("/data")
public class DataHacked {
    
	@POST
    @Produces("application/json;charset=UTF-8")    
    @Path("/refresh")
    public ModifiedResult refresh(@Context HttpServletRequest request,@FormParam("refreshData") String refreshData) {
//		Result result = new Result();	
		request.getSession().setAttribute("refreshData", JSONArray.fromObject(refreshData));
		ModifiedResult result = new ModifiedResult();
        return result;
    }
}
