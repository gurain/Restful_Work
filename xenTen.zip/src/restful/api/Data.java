package restful.api;

import net.sf.json.JSONArray;

import javax.servlet.http.HttpServletRequest;
import javax.ws.rs.FormParam;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.Context;
import restful.bean.Result;

@Path("/data")
public class Data {
    
	@POST
    @Produces("application/json;charset=UTF-8")    
    @Path("/readCommand")
    public Result readCommand(@Context HttpServletRequest request,@FormParam("command") String command) {
		Result result = new Result();	
		request.getSession().setAttribute("commands", JSONArray.fromObject(command));
//		JSONArray jsonArray = JSONArray.fromObject(command);
//		for (int i = 0; i < jsonArray.size(); i++) {
//		    Object element = jsonArray.get(i);
//		    System.out.println("元素 " + i + ": " + element);
//		}
        return result;
    }
}
