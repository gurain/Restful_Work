package restful.interceptor;

import org.jboss.resteasy.core.Headers;
import org.jboss.resteasy.core.ResourceMethodInvoker;
import org.jboss.resteasy.core.ServerResponse;
import org.jboss.resteasy.spi.HttpRequest;
import org.jboss.resteasy.spi.interception.PreProcessInterceptor;
import restful.annotation.BoxPower;
import restful.bean.Result;

import javax.servlet.http.HttpServletRequest;
import javax.ws.rs.core.Context;
import java.lang.reflect.Method;
import java.util.HashMap;


@SuppressWarnings("deprecation")
public class Interceptor4PreProcess implements PreProcessInterceptor {

    @Context
    HttpServletRequest request;

    @Override
    public ServerResponse preProcess(HttpRequest httpRequest, ResourceMethodInvoker resourceMethodInvoker) {
        //获取访问的方法
        Method method = resourceMethodInvoker.getMethod();
        //存在注解
        if (method.isAnnotationPresent(BoxPower.class)) {
            //session中没有设置名字则表示未登录
            if (request.getSession().getAttribute("username") == null) {
                return new ServerResponse(new Result(-20, "无名之辈也敢来挑战？", "/box/ini"), 200, new Headers<>());
            } else {
                //获取map
                HashMap<String, String> powerList = (HashMap<String, String>) request.getSession().getAttribute("powerList");
                //注解
                BoxPower annotation = method.getAnnotation(BoxPower.class);
                //注解上的值
                String value = annotation.value();
                if (powerList.containsKey(value))//存在该权限,放行
                {
                    return null;
                } else {//不存在,不放行
                    return new ServerResponse(new Result(-10, "你想投机取巧，还是乖地按顺序回答我的问题！", ""), 200, new Headers<>());
                }
            }
        }
        return null;
    }

}
