package restful.api;

import java.util.HashMap;

import javax.servlet.http.HttpServletRequest;
import javax.ws.rs.FormParam;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.Context;

import restful.annotation.BoxPower;
import restful.bean.Result;

/*
 *  请同学们配合拦截器代码做适当代码补充。
 */

@Path("/box")
public class GameAPI {
	/**
	 * question:
	 * 0:输入答案,并且请求答案地址
	 * -20:首次答题进行初始化
	 * -10:展示信息,答错嘲讽
	 *
	 * answer:
	 * 0:答对
	 * -10:答错
	 * 10:完成所有答题
	 */

	@Context HttpServletRequest request;

	@POST
	@Path("/ini")
	@Produces("application/json;charset=UTF-8")
	public Result ini(@FormParam("username") String username) {
		HashMap<String,String> powerList = new HashMap<String,String>();
		powerList.put("box1","");
		request.getSession().setAttribute("powerList", powerList);
		request.getSession().setAttribute("username", username);
		return new Result(0,username+",你胆敢来挑战我？那就试试吧！","");
	}

	@POST
	@Path("/question1")
	@Produces("application/json;charset=UTF-8")
	@BoxPower("box1")
	public Result question1() {
		return new Result(0,"1+1=?","/box/answer1");
	}

	@SuppressWarnings("unchecked")
	@POST
	@Path("/answer1")
	@Produces("application/json;charset=UTF-8")
	@BoxPower("box1")
	public Result answer1(@FormParam("answer") String answer) {
		//获取map
		HashMap<String, String> powerList = (HashMap<String, String>) request.getSession().getAttribute("powerList");
		powerList.put("box2","");
		if ("2".equals(answer))
		{
			return new Result(0,"算你运气好，下次就没这么好运了！","/box/question2");
		}
		else
		{
			return new Result(-10,"你真是个衰仔!","");
		}
	}

	@POST
	@Path("/question2")
	@Produces("application/json;charset=UTF-8")
	@BoxPower("box2")
	public Result question2() {
		return new Result(0,"2+2=?","/box/answer2");

	}

	@SuppressWarnings("unchecked")
	@POST
	@Path("/answer2")
	@Produces("application/json;charset=UTF-8")
	@BoxPower("box2")
	public Result answer2(@FormParam("answer") String answer) {
		//获取map
		HashMap<String, String> powerList = (HashMap<String, String>) request.getSession().getAttribute("powerList");
		powerList.put("box3","");
		if ("4".equals(answer))
		{
			return new Result(0,"算你运气好，下次就没这么好运了！","/box/question3");
		}
		else
		{
			return new Result(-10,"你真是个衰仔!","");
		}
	}

	@POST
	@Path("/question3")
	@Produces("application/json;charset=UTF-8")
	@BoxPower("box3")
	public Result question3() {
		return new Result(0,"3+3=?","/box/answer3");

	}

	@SuppressWarnings("unchecked")
	@POST
	@Path("/answer3")
	@Produces("application/json;charset=UTF-8")
	@BoxPower("box3")
	public Result answer3(@FormParam("answer") String answer) {
		//获取map
		HashMap<String, String> powerList = (HashMap<String, String>) request.getSession().getAttribute("powerList");
		powerList.put("box4","");
		if ("6".equals(answer))
		{
			return new Result(0,"算你运气好，下次就没这么好运了！","/box/question3");
		}
		else
		{
			return new Result(-10,"你真是个衰仔!","");
		}
	}


	@POST
	@Path("/question4")
	@Produces("application/json;charset=UTF-8")
	@BoxPower("box4")
	public Result question4() {
		return new Result(0,"4+4=?","/box/answer4");

	}

	@SuppressWarnings("unchecked")
	@POST
	@Path("/answer4")
	@Produces("application/json;charset=UTF-8")
	@BoxPower("box4")
	public Result answer4(@FormParam("answer") String answer) {
		//获取map
		HashMap<String, String> powerList = (HashMap<String, String>) request.getSession().getAttribute("powerList");
		powerList.put("box5","");
		if ("8".equals(answer))
		{
			return new Result(0,"算你运气好，下次就没这么好运了！","/box/question3");
		}
		else
		{
			return new Result(-10,"你真是个衰仔!","");
		}
	}

	@POST
	@Path("/question5")
	@Produces("application/json;charset=UTF-8")
	@BoxPower("box5")
	public Result question5() {
		return new Result(0,"5+5=?","/box/answer5");

	}

	@SuppressWarnings("unchecked")
	@POST
	@Path("/answer5")
	@Produces("application/json;charset=UTF-8")
	@BoxPower("box5")
	public Result answer5(@FormParam("answer") String answer) {
		//获取map
		HashMap<String, String> powerList = (HashMap<String, String>) request.getSession().getAttribute("powerList");
		powerList.put("finish","");
		if ("10".equals(answer))
		{
			//10表示打完了所有题
			return new Result(10,"算你运气好，下次就没这么好运了！","/box/finish");
		}
		else
		{
			return new Result(-10,"你真是个衰仔!","");
		}
	}


	@POST
	@Path("/finish")
	@Produces("application/json;charset=UTF-8")
	@BoxPower("finish")
	public Result finish() {
//		全部完成
		return null;
	}



}
