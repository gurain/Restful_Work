package restful.api;

import restful.entity.Goods;
import restful.entity.Result;

import javax.ws.rs.*;
import java.util.HashMap;
import java.util.Map;

@Path("/caseSale/sale/act/")
public class MyAPI {
    //定义售卖表
    static Map<Integer, Goods> salesMap = new HashMap<Integer, Goods>();

    //初始化
    static {
        salesMap.put(0, new Goods(0, "可乐", 3.0));
        salesMap.put(1, new Goods(1, "雪碧", 3.0));
        salesMap.put(2, new Goods(2, "橙汁", 2.5));
        salesMap.put(3, new Goods(3, "玉泉+C", 7.0));
        salesMap.put(4, new Goods(4, "酱油", 14.0));
        salesMap.put(5, new Goods(5, "水乐动", 4.0));
        salesMap.put(6, new Goods(6, "醋", 18.0));
        salesMap.put(7, new Goods(7, "铅笔", 1.0));
    }

    @Produces("application/json;charset=utf-8")
    @GET
    @Path("{id}/{num}")
    public Result caseSale(@PathParam("id") String i, @PathParam("num") String n, @QueryParam("pay") String pay) {
        Result result;
        try {
            //格式转换
            Integer id = Integer.parseInt(i);
            Integer num = Integer.parseInt(n);
            Double payAmount = Double.parseDouble(pay);

            //获取货物信息
            Goods goods = salesMap.get(id);

            //逻辑判断
            if (goods == null) {
                result = new Result("未注册商品", num, payAmount, -300, Result.CODE_300);
            } else if (id == 7) {
                result = new Result(goods.getName(), num, payAmount, -200, Result.CODE_200);
            } else {
                //总价
                double total = num * goods.getPrice();
                result = (payAmount - total) >= 0 ?
                        new Result(goods.getName(), num, payAmount - total, 0, Result.CODE_0)
                        : new Result(goods.getName(), num, payAmount, -100, Result.CODE_100);
            }
            //返回结果
            return result;
        } catch (NumberFormatException e) {
            e.printStackTrace();
            return null;
        }
    }
}
