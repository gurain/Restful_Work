package restful.entity;

/**
 * Author: GuRain
 * CLassName: Result
 * Package: restful.entity
 * Create: 2023/10/7 - 15:43
 * Version: v1.0
 * Description:
 */
public class Result {
    public static final String CODE_0 = "成功售卖";
    public static final String CODE_100 = "金额不足，全额退款";
    public static final String CODE_200 = "商品库存不足，全额退款";
    public static final String CODE_300 = "无此商品售卖，全额退款";

    private String name;
    private Integer amount;
    private Double change;
    private Integer resultCode;
    private String resultText;

    @Override
    public String toString() {
        return "Result{" +
                "name='" + name + '\'' +
                ", amount=" + amount +
                ", change=" + change +
                ", resultCode=" + resultCode +
                ", resultText='" + resultText + '\'' +
                '}';
    }

    public Result() {

    }

    public Result(String name, Integer amount, Double change, Integer resultCode, String resultText) {
        this.name = name;
        this.amount = amount;
        this.change = change;
        this.resultCode = resultCode;
        this.resultText = resultText;
    }


    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Integer getAmount() {
        return amount;
    }

    public void setAmount(Integer amount) {
        this.amount = amount;
    }

    public Double getChange() {
        return change;
    }

    public void setChange(Double change) {
        this.change = change;
    }

    public Integer getResultCode() {
        return resultCode;
    }

    public void setResultCode(Integer resultCode) {
        this.resultCode = resultCode;
    }

    public String getResultText() {
        return resultText;
    }

    public void setResultText(String resultText) {
        this.resultText = resultText;
    }


}
