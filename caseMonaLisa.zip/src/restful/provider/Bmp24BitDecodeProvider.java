package restful.provider;

import java.awt.image.BufferedImage;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.lang.annotation.Annotation;
import java.lang.reflect.Type;

import javax.imageio.ImageIO;
import javax.ws.rs.Consumes;
import javax.ws.rs.Produces;
import javax.ws.rs.WebApplicationException;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.MultivaluedMap;
import javax.ws.rs.ext.MessageBodyReader;
import javax.ws.rs.ext.MessageBodyWriter;
import javax.ws.rs.ext.Provider;
import org.apache.commons.codec.binary.Base64;
import restful.utils.SimpleUploadUtils;

@Provider
@Consumes("monaLisa/input")
@Produces("monaLisa/output")
public class Bmp24BitDecodeProvider implements MessageBodyReader<BufferedImage>, MessageBodyWriter<BufferedImage> {
	@Override
	public long getSize(BufferedImage bufferedImage, Class<?> clazz, Type type, Annotation[] annotations,
			MediaType mediaType) {
		return -1;// 方法已弃用
	}

	@Override
	public boolean isWriteable(Class<?> clazz, Type type, Annotation[] annotations, MediaType mediaType) {
		return true;
	}

	@Override
	public void writeTo(BufferedImage bufferedImage, Class<?> clazz, Type type, Annotation[] annotations,
			MediaType mediaType, MultivaluedMap<String, Object> multivaluedMap, OutputStream entityStream)
			throws IOException, WebApplicationException {
		Base64 base64 = new Base64();

		// 获取图像的宽度和高度
		int width = bufferedImage.getWidth();
		int height = bufferedImage.getHeight();

		StringBuilder stringBuilder = new StringBuilder();

		// 遍历每个像素
		for (int y = 0; y < height; y++) {
			for (int x = 0; x < width; x++) {
				// 获取每个像素的颜色值
				int color = bufferedImage.getRGB(x, y);
//                // 分离颜色通道
//                int red = (color >> 16) & 0xFF;
//                int green = (color >> 8) & 0xFF;
//                int blue = color & 0xFF;
//                // 取最后一位
//                int redEnd = red & 0x01;
//                int greenEnd = green & 0x01;
//                int blueEnd = blue & 0x01;

				// 取最后一位,同时添加进字符串中
				stringBuilder.append(((color >> 16) & 0xFF) & 0x01);
				stringBuilder.append(((color >> 8) & 0xFF) & 0x01);
				stringBuilder.append((color & 0xFF) & 0x01);
			}
		}

		// 获取隐藏信息的长度
		String contentLength = stringBuilder.substring(0, 32);
		// 进行反序
		String reversedString = reversedString(contentLength);
		// 隐藏信息的长度
		long length = Long.parseLong(reversedString, 2);

		// 定义字节数组
		byte[] byteArray = new byte[(int) length];
		for (int i = 32; i < (length * 8 + 32); i += 8) {
			// 截取字节
			String substringByte = stringBuilder.substring(i, i + 8);
			// 反序
			String reversedByte = reversedString(substringByte);
			// 添加进数组中
			byteArray[(i / 8) - 4] = (byte) Integer.parseInt(reversedByte, 2);
		}

		// 进行base64编码
		byte[] encode = base64.encode(byteArray);
		entityStream.write(encode);
	}

	/**
	 * 将输入的字符串反序
	 * 
	 * @param input 输入的字符串
	 * @return 转序后的字符串
	 */
	public static String reversedString(String input) {
		// 将字符串转换为字符数组
		char[] charArray = input.toCharArray();
		// 反转字符数组
		for (int i = 0; i < charArray.length / 2; i++) {
			char temp = charArray[i];
			charArray[i] = charArray[charArray.length - 1 - i];
			charArray[charArray.length - 1 - i] = temp;
		}
		// 将反转后的字符数组转换回字符串并且返回
		return new String(charArray);
	}

	@Override
	public boolean isReadable(Class<?> clazz, Type type, Annotation[] annotations, MediaType mediaType) {
		return true;
	}

	@Override
	public BufferedImage readFrom(Class<BufferedImage> clazz, Type type, Annotation[] annotations, MediaType mediaType,
			MultivaluedMap<String, String> multivaluedMap, InputStream entityStream)
			throws IOException, WebApplicationException {
		ByteArrayInputStream byteArrayInputStream = new ByteArrayInputStream(
				SimpleUploadUtils.getSingleFileBytsFromEntity(entityStream));
		BufferedImage bufferedImage = ImageIO.read(byteArrayInputStream);
		return bufferedImage;
	}

}
